from django.apps import AppConfig


class TestresultsConfig(AppConfig):
    name = 'testResults'
