from django.test import TestCase

from .models import Transfer
from core.models import Patient, Hospital
# Create your tests here.
