from django.apps import AppConfig


class ApointmentsConfig(AppConfig):
    name = 'appointments'
