from django.apps import AppConfig


class SysstatsConfig(AppConfig):
    name = 'sysstats'
