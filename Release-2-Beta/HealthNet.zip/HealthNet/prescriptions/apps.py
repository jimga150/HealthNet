from django.apps import AppConfig


class PerscriptionsConfig(AppConfig):
    name = 'prescriptions'
